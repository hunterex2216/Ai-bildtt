package com.example.service

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.util.Log
import androidx.core.content.ContextCompat
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

private const val TAG = "AgentSttModule"
private const val PREFS_NAME = "archer_stt_prefs"
private const val KEY_STT_LANGUAGE = "stt_language_code"
private const val KEY_HANDS_FREE_CONTINUOUS = "stt_hands_free_continuous"
private const val PARTIAL_SILENCE_FINALIZE_MS = 1650L

data class SttEngineState(
    val isListening: Boolean = false,
    val isHandsFreeContinuous: Boolean = false,
    val isRecognitionServiceAvailable: Boolean = true,
    val languageCode: String = "bn-BD",
    val languageLabel: String = "বাংলা (bn-BD)",
    val partialTranscript: String = "",
    val lastFinalTranscript: String = "",
    val rmsLevel: Float = 0f,
    val confidenceScore: Float = 0f,
    val errorCode: Int? = null,
    val statusMessage: String = "\"Hey Cube\" বলুন অথবা মাইকে ট্যাপ করে আদেশ দিন"
)

/**
 * Dedicated Android Speech-to-Text (STT) engine built on [SpeechRecognizer] and [RecognitionListener].
 *
 * Key capabilities:
 * - Real-time streaming partial transcripts via [RecognitionListener.onPartialResults].
 * - Automatic partial-transcript recovery & silence debounce auto-finalization so spoken commands
 *   are never lost even if [RecognitionListener.onError] (`ERROR_NO_MATCH` / `ERROR_SPEECH_TIMEOUT`)
 *   fires after speech was captured.
 * - Multi-language recognition (`bn-BD` বাংলা, `en-US` English, `hi-IN` हिन्दी) with automatic
 *   extra languages hint for mixed Banglish/English commands.
 * - Continuous Hands-Free loop support that pauses while TTS is speaking and resumes automatically
 *   after TTS finishes or after transient recognizer errors.
 */
class AgentSttModule(
    private val context: Context,
    private val isTtsCurrentlySpeaking: () -> Boolean,
    private val onPartialSpeechUpdate: (String) -> Unit,
    private val onFinalSpeechRecognized: (transcript: String, confidence: Float, isFollowUp: Boolean) -> Unit,
    private val onStateChanged: (SttEngineState) -> Unit = {}
) {
    private val appContext = context.applicationContext
    private val prefs = appContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    private val mainHandler = Handler(Looper.getMainLooper())

    private var speechRecognizer: SpeechRecognizer? = null
    private var isCommandFollowUpSession: Boolean = false
    private var bufferedPartialText: String = ""
    private var sessionResultDelivered: Boolean = false
    private var consecutiveErrorCount: Int = 0

    private val partialDebounceRunnable = Runnable {
        val candidate = bufferedPartialText.trim()
        if (candidate.isNotBlank() && !sessionResultDelivered) {
            Log.d(TAG, "Auto-finalizing buffered partial transcript after silence: $candidate")
            deliverFinalTranscript(candidate, confidence = 0.82f)
        }
    }

    private val autoRestartRunnable = Runnable {
        if (!isTtsCurrentlySpeaking() &&
            (_state.value.isHandsFreeContinuous || CubeSentinelBus.state.value.isSentinelActive)
        ) {
            startListening(isCommandFollowUp = isCommandFollowUpSession)
        }
    }

    private val _state = MutableStateFlow(
        SttEngineState(
            isHandsFreeContinuous = prefs.getBoolean(KEY_HANDS_FREE_CONTINUOUS, false),
            isRecognitionServiceAvailable = runCatching {
                SpeechRecognizer.isRecognitionAvailable(appContext)
            }.getOrDefault(true),
            languageCode = prefs.getString(KEY_STT_LANGUAGE, "bn-BD") ?: "bn-BD",
            languageLabel = formatLanguageLabel(prefs.getString(KEY_STT_LANGUAGE, "bn-BD") ?: "bn-BD")
        )
    )
    val state: StateFlow<SttEngineState> = _state.asStateFlow()

    fun hasRecordAudioPermission(): Boolean {
        return ContextCompat.checkSelfPermission(
            appContext,
            Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED
    }

    fun setHandsFreeContinuousMode(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_HANDS_FREE_CONTINUOUS, enabled).apply()
        updateState {
            copy(
                isHandsFreeContinuous = enabled,
                statusMessage = if (enabled) {
                    "হ্যান্ডস-ফ্রি ভয়েস মোড চালু — সরাসরি কথা বলুন"
                } else {
                    "হ্যান্ডস-ফ্রি মোড বন্ধ — মাইকে ট্যাপ করে কথা বলুন"
                }
            )
        }
        if (enabled && hasRecordAudioPermission() && !isTtsCurrentlySpeaking()) {
            startListening(isCommandFollowUp = true)
        } else if (!enabled && !CubeSentinelBus.state.value.isSentinelActive) {
            stopListening()
        }
    }

    fun toggleHandsFreeContinuousMode(): Boolean {
        val next = !_state.value.isHandsFreeContinuous
        setHandsFreeContinuousMode(next)
        return next
    }

    fun cycleLanguage(): String {
        val nextLang = when (_state.value.languageCode) {
            "bn-BD" -> "en-US"
            "en-US" -> "hi-IN"
            else -> "bn-BD"
        }
        setLanguage(nextLang)
        return nextLang
    }

    fun setLanguage(languageCode: String) {
        val normalized = when {
            languageCode.startsWith("bn", ignoreCase = true) -> "bn-BD"
            languageCode.startsWith("hi", ignoreCase = true) -> "hi-IN"
            else -> "en-US"
        }
        prefs.edit().putString(KEY_STT_LANGUAGE, normalized).apply()
        val label = formatLanguageLabel(normalized)
        updateState {
            copy(
                languageCode = normalized,
                languageLabel = label,
                statusMessage = "ভয়েস ভাষা: $label"
            )
        }
        if (_state.value.isListening) {
            startListening(isCommandFollowUp = isCommandFollowUpSession)
        }
    }

    fun startListening(isCommandFollowUp: Boolean = true) {
        mainHandler.post {
            startListeningOnMainThread(isCommandFollowUp)
        }
    }

    private fun startListeningOnMainThread(isCommandFollowUp: Boolean) {
        mainHandler.removeCallbacks(partialDebounceRunnable)
        mainHandler.removeCallbacks(autoRestartRunnable)

        if (!hasRecordAudioPermission()) {
            updateState {
                copy(
                    isListening = false,
                    rmsLevel = 0f,
                    statusMessage = "মাইক্রোফোন পারমিশন প্রয়োজন — মাইকে ট্যাপ করে Allow করুন"
                )
            }
            return
        }

        val available = runCatching {
            SpeechRecognizer.isRecognitionAvailable(appContext)
        }.getOrDefault(false)

        if (!available) {
            updateState {
                copy(
                    isListening = false,
                    isRecognitionServiceAvailable = false,
                    rmsLevel = 0f,
                    statusMessage = "অন-ডিভাইস ভয়েস সার্ভিস অনুপস্থিত — সিস্টেম ভয়েস পপআপ বা টাইপিং ব্যবহার করুন"
                )
            }
            return
        }

        isCommandFollowUpSession = isCommandFollowUp
        bufferedPartialText = ""
        sessionResultDelivered = false

        destroyRecognizerQuietly()

        try {
            val recognizer = SpeechRecognizer.createSpeechRecognizer(appContext)
            speechRecognizer = recognizer
            recognizer.setRecognitionListener(createRecognitionListener())

            val selectedLang = _state.value.languageCode
            val recognizeIntent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(
                    RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                    RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
                )
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, selectedLang)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, selectedLang)
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, appContext.packageName)
                // Provide generous silence thresholds so natural pauses don't cut off speech early
                putExtra(
                    RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS,
                    1800L
                )
                putExtra(
                    RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS,
                    1400L
                )
                putExtra(
                    RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS,
                    1200L
                )
            }

            recognizer.startListening(recognizeIntent)
            updateState {
                copy(
                    isListening = true,
                    isRecognitionServiceAvailable = true,
                    partialTranscript = "",
                    errorCode = null,
                    statusMessage = when {
                        isCommandFollowUp -> "জি স্যার, শুনছি (${_state.value.languageLabel})... আপনার আদেশ বলুন"
                        _state.value.isHandsFreeContinuous -> "হ্যান্ডস-ফ্রি মাইক সক্রিয় — কথা বললেই কমান্ড চলবে"
                        else -> "Hey Cube গার্ড সক্রিয় — 'Hey Cube' বলুন অথবা আদেশ দিন"
                    }
                )
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to start SpeechRecognizer: ${e.message}", e)
            updateState {
                copy(
                    isListening = false,
                    rmsLevel = 0f,
                    statusMessage = "ভয়েস রিকগনিশন শুরু করা যায়নি: ${e.localizedMessage ?: "পুনরায় চেষ্টা করুন"}"
                )
            }
        }
    }

    private fun createRecognitionListener(): RecognitionListener {
        return object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                consecutiveErrorCount = 0
                val sentinelActive = CubeSentinelBus.state.value.isSentinelActive
                updateState {
                    copy(
                        isListening = true,
                        errorCode = null,
                        statusMessage = when {
                            isCommandFollowUpSession -> "জি স্যার, শুনছি... এখন আপনার কথা বলুন"
                            isHandsFreeContinuous -> "হ্যান্ডস-ফ্রি লিসেনিং সক্রিয় — সরাসরি বলুন..."
                            sentinelActive -> "Hey Cube গার্ড সক্রিয় — 'Hey Cube' বলে ডাকুন..."
                            else -> "শুনছি... এখন আপনার কথা বলুন"
                        }
                    )
                }
            }

            override fun onBeginningOfSpeech() {
                mainHandler.removeCallbacks(partialDebounceRunnable)
                updateState {
                    copy(
                        isListening = true,
                        statusMessage = "কথা শনাক্ত হচ্ছে..."
                    )
                }
            }

            override fun onRmsChanged(rmsdB: Float) {
                val normalized = ((rmsdB + 2f) / 12f).coerceIn(0.05f, 1f)
                updateState { copy(rmsLevel = normalized) }
            }

            override fun onBufferReceived(buffer: ByteArray?) {}

            override fun onEndOfSpeech() {
                updateState {
                    copy(
                        rmsLevel = 0f,
                        statusMessage = "আপনার কথা প্রসেস করা হচ্ছে..."
                    )
                }
                // If partial results were already received, schedule a fallback finalization in case onResults lags
                if (bufferedPartialText.isNotBlank() && !sessionResultDelivered) {
                    mainHandler.removeCallbacks(partialDebounceRunnable)
                    mainHandler.postDelayed(partialDebounceRunnable, 900L)
                }
            }

            override fun onPartialResults(partialResults: Bundle?) {
                val partialList = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val bestPartial = partialList?.firstOrNull().orEmpty().trim()
                if (bestPartial.isNotBlank()) {
                    bufferedPartialText = bestPartial
                    updateState {
                        copy(
                            isListening = true,
                            partialTranscript = bestPartial,
                            statusMessage = "শুনছি: \"$bestPartial\""
                        )
                    }
                    onPartialSpeechUpdate(bestPartial)

                    // Reset silence debounce timer so if user stops speaking and Android doesn't fire onResults,
                    // we still execute the spoken command automatically after PARTIAL_SILENCE_FINALIZE_MS.
                    mainHandler.removeCallbacks(partialDebounceRunnable)
                    mainHandler.postDelayed(partialDebounceRunnable, PARTIAL_SILENCE_FINALIZE_MS)
                }
            }

            override fun onResults(results: Bundle?) {
                mainHandler.removeCallbacks(partialDebounceRunnable)
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val confidenceScores = results?.getFloatArray(SpeechRecognizer.CONFIDENCE_SCORES)
                val bestMatch = matches?.firstOrNull().orEmpty().trim()
                    .ifBlank { bufferedPartialText.trim() }
                val topConfidence = confidenceScores?.firstOrNull()?.takeIf { it > 0f } ?: 0.92f

                if (bestMatch.isNotBlank()) {
                    deliverFinalTranscript(bestMatch, topConfidence)
                } else {
                    updateState {
                        copy(
                            isListening = false,
                            rmsLevel = 0f,
                            statusMessage = "কোনো কথা শোনা যায়নি — আবার বলুন"
                        )
                    }
                    scheduleContinuousRestartIfNeeded(delayMs = 550L)
                }
            }

            override fun onError(error: Int) {
                mainHandler.removeCallbacks(partialDebounceRunnable)

                // CRITICAL RECOVERY: If the user spoke and partial results were captured before
                // ERROR_NO_MATCH (7) or ERROR_SPEECH_TIMEOUT (6) or ERROR_CLIENT (5), execute the partial text!
                val recoveredText = bufferedPartialText.trim()
                if (recoveredText.isNotBlank() && !sessionResultDelivered) {
                    Log.d(TAG, "Recovering spoken command from partial transcript on error($error): $recoveredText")
                    deliverFinalTranscript(recoveredText, confidence = 0.78f)
                    return
                }

                consecutiveErrorCount = (consecutiveErrorCount + 1).coerceAtMost(6)
                val friendlyError = mapSpeechErrorToMessage(error)
                updateState {
                    copy(
                        isListening = false,
                        rmsLevel = 0f,
                        errorCode = error,
                        statusMessage = friendlyError
                    )
                }

                destroyRecognizerQuietly()

                // Auto-restart in Hands-Free Continuous mode or Sentinel mode unless permission is missing
                if (error != SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
                    val backoffDelay = when (error) {
                        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> 1200L
                        SpeechRecognizer.ERROR_TOO_MANY_REQUESTS -> 1600L
                        else -> (550L + (consecutiveErrorCount * 200L)).coerceAtMost(1800L)
                    }
                    scheduleContinuousRestartIfNeeded(delayMs = backoffDelay)
                }
            }

            override fun onEvent(eventType: Int, params: Bundle?) {}
        }
    }

    private fun deliverFinalTranscript(transcript: String, confidence: Float) {
        if (sessionResultDelivered) return
        sessionResultDelivered = true
        bufferedPartialText = ""
        mainHandler.removeCallbacks(partialDebounceRunnable)

        val cleaned = transcript.trim()
        val wasFollowUp = isCommandFollowUpSession
        isCommandFollowUpSession = false

        destroyRecognizerQuietly()

        updateState {
            copy(
                isListening = false,
                rmsLevel = 0f,
                partialTranscript = cleaned,
                lastFinalTranscript = cleaned,
                confidenceScore = confidence,
                errorCode = null,
                statusMessage = "কমান্ড গৃহীত: \"$cleaned\""
            )
        }

        onFinalSpeechRecognized(cleaned, confidence, wasFollowUp)
    }

    /**
     * Handles speech result returned from the system [RecognizerIntent.ACTION_RECOGNIZE_SPEECH]
     * ActivityResult fallback dialog when on-device background service is unavailable.
     */
    fun onExternalActivityResult(recognizedText: String) {
        val cleaned = recognizedText.trim()
        if (cleaned.isBlank()) return
        sessionResultDelivered = false
        deliverFinalTranscript(cleaned, confidence = 0.95f)
    }

    fun buildSystemRecognizerFallbackIntent(): Intent {
        val selectedLang = _state.value.languageCode
        return Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(
                RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
            )
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, selectedLang)
            putExtra(
                RecognizerIntent.EXTRA_PROMPT,
                "জি স্যার, আপনার আদেশ বলুন (বাংলা / English / हिन्दी)"
            )
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }
    }

    fun scheduleContinuousRestartIfNeeded(delayMs: Long = 500L) {
        mainHandler.removeCallbacks(autoRestartRunnable)
        if (_state.value.isHandsFreeContinuous || CubeSentinelBus.state.value.isSentinelActive) {
            mainHandler.postDelayed(autoRestartRunnable, delayMs)
        }
    }

    fun pauseForTtsOutput() {
        mainHandler.removeCallbacks(partialDebounceRunnable)
        mainHandler.removeCallbacks(autoRestartRunnable)
        if (_state.value.isListening || speechRecognizer != null) {
            destroyRecognizerQuietly()
            updateState {
                copy(
                    isListening = false,
                    rmsLevel = 0f
                )
            }
        }
    }

    fun stopListening() {
        mainHandler.removeCallbacks(partialDebounceRunnable)
        mainHandler.removeCallbacks(autoRestartRunnable)
        bufferedPartialText = ""
        destroyRecognizerQuietly()
        updateState {
            copy(
                isListening = false,
                rmsLevel = 0f,
                statusMessage = "ভয়েস মাইক বন্ধ আছে — কথা বলতে মাইকে ট্যাপ করুন"
            )
        }
    }

    fun release() {
        mainHandler.removeCallbacksAndMessages(null)
        destroyRecognizerQuietly()
    }

    private fun destroyRecognizerQuietly() {
        val current = speechRecognizer
        speechRecognizer = null
        if (current != null) {
            try {
                current.stopListening()
            } catch (_: Exception) {
            }
            try {
                current.cancel()
            } catch (_: Exception) {
            }
            try {
                current.destroy()
            } catch (_: Exception) {
            }
        }
    }

    private fun mapSpeechErrorToMessage(error: Int): String {
        val autoLoop = _state.value.isHandsFreeContinuous || CubeSentinelBus.state.value.isSentinelActive
        return when (error) {
            SpeechRecognizer.ERROR_NO_MATCH -> {
                if (autoLoop) "হ্যান্ডস-ফ্রি মাইক প্রস্তুত — আপনার কথা বলুন..."
                else "কথাটি স্পষ্ট বোঝা যায়নি — আবার মাইকে বলুন"
            }
            SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> {
                if (autoLoop) "হ্যান্ডস-ফ্রি মাইক শুনছে — যেকোনো সময় কথা বলুন..."
                else "কোনো শব্দ পাওয়া যায়নি — মাইকে ট্যাপ করে আবার বলুন"
            }
            SpeechRecognizer.ERROR_NETWORK,
            SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "নেটওয়ার্ক ধীরগতির — আবার চেষ্টা করা হচ্ছে"
            SpeechRecognizer.ERROR_AUDIO -> "মাইক্রোফোন অডিও ক্যাপচারে সমস্যা হয়েছে"
            SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "ভয়েস ইঞ্জিন রিসেট হচ্ছে — অনুগ্রহ করে কথা বলুন"
            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "মাইক্রোফোন পারমিশন নেই — Allow করুন"
            SpeechRecognizer.ERROR_CLIENT -> {
                if (autoLoop) "হ্যান্ডস-ফ্রি মাইক প্রস্তুত..."
                else "মাইকে ট্যাপ করে আপনার আদেশ বলুন"
            }
            else -> "আবার বলুন অথবা নিচে টাইপ করুন"
        }
    }

    private fun formatLanguageLabel(code: String): String {
        return when {
            code.startsWith("bn", ignoreCase = true) -> "বাংলা (bn-BD)"
            code.startsWith("hi", ignoreCase = true) -> "हिन्दी (hi-IN)"
            else -> "English (en-US)"
        }
    }

    private inline fun updateState(transform: SttEngineState.() -> SttEngineState) {
        val next = _state.value.transform()
        _state.value = next
        onStateChanged(next)
    }
}
