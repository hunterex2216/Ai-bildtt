package com.example.service

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

private const val TAG = "AgentTtsModule"
private const val GOOGLE_TTS_PACKAGE = "com.google.android.tts"

data class TtsEngineState(
    val isInitialized: Boolean = false,
    val isEnabled: Boolean = true,
    val isSpeaking: Boolean = false,
    val speechRate: Float = 0.95f,
    val pitch: Float = 0.80f,
    val voiceProfile: String = "DEEP_JARVIS",
    val activeVoiceLocaleLabel: String = "Deep & Clean • বাংলা / English",
    val lastSpokenText: String = "জি স্যার, আমি প্রস্তুত। আপনার যেকোনো প্রশ্ন বা আদেশ বলুন।",
    val enginePackage: String = "System TTS"
)

private data class TrackedUtterance(
    val originalText: String,
    val spokenText: String,
    val usedNativeNonLatin: Boolean,
    val isWakeGreeting: Boolean,
    val isLastChunkInBatch: Boolean,
    var startElapsedMs: Long = 0L
)

/**
 * Dedicated Android TextToSpeech (TTS) module for ARCHER AI / Cube AI.
 * Supports automatic Bengali (`bn-BD` / `bn-IN`), Hindi (`hi-IN`), and English (`en-US` / `en-IN`)
 * script detection, audio focus management, sentence chunking, markdown sanitization,
 * and automatic phonetic fallback when an emulator or device lacks offline Bengali/Hindi voice packs.
 */
class AgentTtsModule(
    private val context: Context,
    private val onSpeechStarted: () -> Unit = {},
    private val onSpeechCompleted: (wasWakeGreeting: Boolean) -> Unit = {}
) {
    private val appContext = context.applicationContext
    private val mainHandler = Handler(Looper.getMainLooper())
    private val audioManager = appContext.getSystemService(Context.AUDIO_SERVICE) as? AudioManager

    private var tts: TextToSpeech? = null
    private var isEngineReady = false
    private var triedDefaultEngineFallback = false

    private var hasNativeBengaliVoice = false
    private var hasNativeHindiVoice = false
    private var preferredBengaliVoice: Voice? = null
    private var preferredHindiVoice: Voice? = null
    private var preferredEnglishVoice: Voice? = null

    private var audioFocusRequest: AudioFocusRequest? = null
    private var pendingUtteranceRequest: Pair<String, Boolean>? = null
    private val activeUtterances = ConcurrentHashMap<String, TrackedUtterance>()
    private var safetyResetRunnable: Runnable? = null

    private val _state = MutableStateFlow(TtsEngineState())
    val state: StateFlow<TtsEngineState> = _state.asStateFlow()

    private val speechAudioAttributes: AudioAttributes by lazy {
        AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_MEDIA)
            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
            .build()
    }

    init {
        initializeEngine(preferGoogleEngine = true)
    }

    private fun initializeEngine(preferGoogleEngine: Boolean) {
        try {
            val listener = TextToSpeech.OnInitListener { status ->
                if (status == TextToSpeech.SUCCESS) {
                    onEngineInitialized()
                } else if (preferGoogleEngine && !triedDefaultEngineFallback) {
                    triedDefaultEngineFallback = true
                    Log.w(TAG, "Google TTS init returned $status, falling back to default system TTS engine")
                    initializeEngine(preferGoogleEngine = false)
                } else {
                    Log.e(TAG, "TextToSpeech initialization failed with status=$status")
                    _state.value = _state.value.copy(
                        isInitialized = false,
                        activeVoiceLocaleLabel = "TTS অনুপস্থিত"
                    )
                }
            }

            tts = if (preferGoogleEngine) {
                TextToSpeech(appContext, listener, GOOGLE_TTS_PACKAGE)
            } else {
                TextToSpeech(appContext, listener)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Exception creating TextToSpeech instance", e)
            if (preferGoogleEngine && !triedDefaultEngineFallback) {
                triedDefaultEngineFallback = true
                initializeEngine(preferGoogleEngine = false)
            }
        }
    }

    private fun onEngineInitialized() {
        val engine = tts ?: return
        isEngineReady = true

        try {
            engine.setAudioAttributes(speechAudioAttributes)
            engine.setSpeechRate(_state.value.speechRate)
            engine.setPitch(_state.value.pitch)
        } catch (e: Exception) {
            Log.w(TAG, "Failed configuring base TTS attributes", e)
        }

        discoverInstalledVoices(engine)
        attachUtteranceListener(engine)

        val enginePkg = try {
            engine.defaultEngine ?: GOOGLE_TTS_PACKAGE
        } catch (_: Exception) {
            GOOGLE_TTS_PACKAGE
        }

        _state.value = _state.value.copy(
            isInitialized = true,
            enginePackage = enginePkg,
            activeVoiceLocaleLabel = if (hasNativeBengaliVoice) {
                "বাংলা (bn-BD) • Native"
            } else {
                "বাংলা/English (Auto Phonetic)"
            }
        )

        // Immediately speak any utterance that was queued while engine was warming up
        pendingUtteranceRequest?.let { (queuedText, isWake) ->
            pendingUtteranceRequest = null
            speak(queuedText, isWakeGreeting = isWake)
        }
    }

    private fun discoverInstalledVoices(engine: TextToSpeech) {
        try {
            val voices = engine.voices.orEmpty()

            val maleOrDeepRank: (Voice) -> Int = { v ->
                val n = v.name.lowercase()
                when {
                    n.contains("male") || n.contains("iom") || n.contains("rjs") || n.contains("ban") ||
                        n.contains("hid") || n.contains("en-us-x-tpd") || n.contains("en-gb-x-gbd") ||
                        n.contains("bn-bd-x-ban") || n.contains("network") -> 0
                    else -> 1
                }
            }

            preferredBengaliVoice = voices.filter { v ->
                val lang = v.locale?.language?.lowercase().orEmpty()
                val country = v.locale?.country?.uppercase().orEmpty()
                val notInstalled = v.features?.contains(TextToSpeech.Engine.KEY_FEATURE_NOT_INSTALLED) == true
                (lang == "bn" || lang == "ben") && country == "BD" && !notInstalled
            }.minByOrNull(maleOrDeepRank) ?: voices.filter { v ->
                val lang = v.locale?.language?.lowercase().orEmpty()
                val notInstalled = v.features?.contains(TextToSpeech.Engine.KEY_FEATURE_NOT_INSTALLED) == true
                (lang == "bn" || lang == "ben") && !notInstalled
            }.minByOrNull(maleOrDeepRank)

            preferredHindiVoice = voices.filter { v ->
                val lang = v.locale?.language?.lowercase().orEmpty()
                val notInstalled = v.features?.contains(TextToSpeech.Engine.KEY_FEATURE_NOT_INSTALLED) == true
                (lang == "hi" || lang == "hin") && !notInstalled
            }.minByOrNull(maleOrDeepRank)

            preferredEnglishVoice = voices.filter { v ->
                val lang = v.locale?.language?.lowercase().orEmpty()
                val country = v.locale?.country?.uppercase().orEmpty()
                val notInstalled = v.features?.contains(TextToSpeech.Engine.KEY_FEATURE_NOT_INSTALLED) == true
                lang == "en" && (country == "US" || country == "GB" || country == "IN") && !notInstalled
            }.minByOrNull(maleOrDeepRank)

            hasNativeBengaliVoice = preferredBengaliVoice != null || run {
                val bnBd = Locale.forLanguageTag("bn-BD")
                val bnIn = Locale.forLanguageTag("bn-IN")
                val availBd = engine.isLanguageAvailable(bnBd)
                val availIn = engine.isLanguageAvailable(bnIn)
                availBd >= TextToSpeech.LANG_AVAILABLE || availIn >= TextToSpeech.LANG_AVAILABLE
            }

            hasNativeHindiVoice = preferredHindiVoice != null || run {
                val hiIn = Locale.forLanguageTag("hi-IN")
                engine.isLanguageAvailable(hiIn) >= TextToSpeech.LANG_AVAILABLE
            }
        } catch (e: Exception) {
            Log.w(TAG, "Voice discovery error", e)
            hasNativeBengaliVoice = false
            hasNativeHindiVoice = false
        }
    }

    private fun attachUtteranceListener(engine: TextToSpeech) {
        engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {
                if (utteranceId != null) {
                    activeUtterances[utteranceId]?.startElapsedMs = SystemClock.elapsedRealtime()
                }
                mainHandler.post {
                    _state.value = _state.value.copy(isSpeaking = true)
                    onSpeechStarted()
                }
            }

            override fun onDone(utteranceId: String?) {
                val tracked = if (utteranceId != null) activeUtterances.remove(utteranceId) else null
                val elapsedMs = if (tracked != null && tracked.startElapsedMs > 0L) {
                    SystemClock.elapsedRealtime() - tracked.startElapsedMs
                } else {
                    500L
                }

                // Zero-silence verification:
                // If an emulator claims bn-BD/hi-IN is available but finishes synthesizing a >5 char
                // non-Latin sentence in under 170ms (meaning 0 audio frames were produced),
                // automatically fall back to phonetic English so the user hears the reply out loud!
                if (tracked != null && tracked.usedNativeNonLatin && tracked.originalText.length > 5 && elapsedMs < 170L) {
                    Log.w(TAG, "Native non-Latin synthesis finished in ${elapsedMs}ms (silent skip); switching to phonetic fallback")
                    hasNativeBengaliVoice = false
                    hasNativeHindiVoice = false
                    mainHandler.post {
                        _state.value = _state.value.copy(activeVoiceLocaleLabel = "বাংলা/English (Phonetic Clear)")
                        speakPhoneticFallbackNow(tracked.originalText, tracked.isWakeGreeting)
                    }
                    return
                }

                if (tracked == null || tracked.isLastChunkInBatch) {
                    mainHandler.post {
                        cancelSafetyReset()
                        abandonAudioFocus()
                        _state.value = _state.value.copy(isSpeaking = false)
                        onSpeechCompleted(tracked?.isWakeGreeting == true)
                    }
                }
            }

            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                handleUtteranceError(utteranceId)
            }

            override fun onError(utteranceId: String?, errorCode: Int) {
                handleUtteranceError(utteranceId)
            }
        })
    }

    private fun handleUtteranceError(utteranceId: String?) {
        val tracked = if (utteranceId != null) activeUtterances.remove(utteranceId) else null
        mainHandler.post {
            if (tracked != null && tracked.usedNativeNonLatin) {
                hasNativeBengaliVoice = false
                hasNativeHindiVoice = false
                speakPhoneticFallbackNow(tracked.originalText, tracked.isWakeGreeting)
            } else {
                cancelSafetyReset()
                abandonAudioFocus()
                _state.value = _state.value.copy(isSpeaking = false)
                onSpeechCompleted(tracked?.isWakeGreeting == true)
            }
        }
    }

    /**
     * Speaks the given agent response aloud if TTS is enabled.
     * Even when `forceSpeakWhenMuted` is true (e.g., user explicitly taps "শুনুন / Replay" or "ভয়েস টেস্ট"),
     * it will unmute or speak immediately.
     */
    fun speak(
        rawText: String,
        isWakeGreeting: Boolean = false,
        forceSpeakWhenMuted: Boolean = false
    ) {
        val sanitized = sanitizeForSpeech(rawText)
        if (sanitized.isBlank()) return

        _state.value = _state.value.copy(lastSpokenText = sanitized)

        if (!_state.value.isEnabled && !forceSpeakWhenMuted) {
            if (isWakeGreeting) {
                mainHandler.postDelayed({ onSpeechCompleted(true) }, 250L)
            }
            return
        }

        if (forceSpeakWhenMuted && !_state.value.isEnabled) {
            _state.value = _state.value.copy(isEnabled = true)
        }

        if (!isEngineReady || tts == null) {
            pendingUtteranceRequest = sanitized to isWakeGreeting
            initializeEngine(preferGoogleEngine = !triedDefaultEngineFallback)
            return
        }

        mainHandler.post {
            dispatchSpeechChunks(sanitized, isWakeGreeting)
        }
    }

    fun replayLastResponse() {
        val textToReplay = _state.value.lastSpokenText.ifBlank {
            "জি স্যার, আমি প্রস্তুত। আপনার যেকোনো প্রশ্ন বা আদেশ বলুন।"
        }
        speak(textToReplay, isWakeGreeting = false, forceSpeakWhenMuted = true)
    }

    fun testVoiceOutput() {
        speak(
            rawText = "জি স্যার! আর্চার এআই ভয়েস ইঞ্জিন সম্পূর্ণ সচল আছে। আপনি বাংলা, ইংরেজি বা হিন্দিতে যেকোনো আদেশ করতে পারেন।",
            isWakeGreeting = false,
            forceSpeakWhenMuted = true
        )
    }

    fun setEnabled(enabled: Boolean) {
        if (!enabled) {
            stopSpeaking()
            _state.value = _state.value.copy(isEnabled = false, isSpeaking = false)
        } else {
            _state.value = _state.value.copy(isEnabled = true)
            speak("ভয়েস স্পিকার চালু করা হয়েছে স্যার।")
        }
    }

    fun toggleEnabled(): Boolean {
        val next = !_state.value.isEnabled
        setEnabled(next)
        return next
    }

    fun setSpeechRate(rate: Float) {
        val clamped = rate.coerceIn(0.60f, 1.60f)
        _state.value = _state.value.copy(speechRate = clamped)
        try {
            tts?.setSpeechRate(clamped)
        } catch (_: Exception) {
        }
    }

    fun setPitch(pitch: Float) {
        val clamped = pitch.coerceIn(0.55f, 1.45f)
        _state.value = _state.value.copy(pitch = clamped)
        try {
            tts?.setPitch(clamped)
        } catch (_: Exception) {
        }
    }

    fun applyVoiceProfile(profile: String) {
        val upper = profile.uppercase()
        val (targetPitch, targetRate) = when (upper) {
            "DEEP_JARVIS" -> 0.80f to 0.95f
            "CLEAN_STUDIO" -> 0.90f to 0.98f
            "ULTRA_DEEP" -> 0.72f to 0.92f
            else -> 1.00f to 1.00f
        }
        _state.value = _state.value.copy(
            voiceProfile = upper,
            pitch = targetPitch,
            speechRate = targetRate
        )
        try {
            tts?.setPitch(targetPitch)
            tts?.setSpeechRate(targetRate)
        } catch (_: Exception) {
        }
    }

    fun stopSpeaking() {
        mainHandler.post {
            cancelSafetyReset()
            activeUtterances.clear()
            try {
                tts?.stop()
            } catch (_: Exception) {
            }
            abandonAudioFocus()
            _state.value = _state.value.copy(isSpeaking = false)
        }
    }

    fun release() {
        stopSpeaking()
        try {
            tts?.shutdown()
        } catch (_: Exception) {
        }
        tts = null
        isEngineReady = false
    }

    private fun dispatchSpeechChunks(sanitizedText: String, isWakeGreeting: Boolean) {
        val engine = tts ?: return
        try {
            ensureAudibleMediaStreamVolume()
            requestAudioFocusForSpeech()

            engine.setSpeechRate(_state.value.speechRate)
            engine.setPitch(_state.value.pitch)

            val chunks = splitIntoNaturalChunks(sanitizedText)
            if (chunks.isEmpty()) return

            _state.value = _state.value.copy(isSpeaking = true)
            onSpeechStarted()

            var totalEstimatedChars = 0

            chunks.forEachIndexed { index, chunk ->
                val queueMode = if (index == 0) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD
                val isLast = index == chunks.lastIndex
                val utteranceId = if (isWakeGreeting && isLast) {
                    "UTTERANCE_WAKE_GREETING_${System.currentTimeMillis()}"
                } else {
                    "ARCHER_TTS_${System.currentTimeMillis()}_$index"
                }

                val hasBengali = chunk.any { it.code in 0x0980..0x09FF }
                val hasHindi = chunk.any { it.code in 0x0900..0x097F }

                val spokenChunk: String
                val usedNativeNonLatin: Boolean

                when {
                    hasBengali && hasNativeBengaliVoice -> {
                        applyBengaliVoice(engine)
                        spokenChunk = chunk
                        usedNativeNonLatin = true
                        _state.value = _state.value.copy(activeVoiceLocaleLabel = "বাংলা (bn-BD)")
                    }
                    hasHindi && hasNativeHindiVoice -> {
                        applyHindiVoice(engine)
                        spokenChunk = chunk
                        usedNativeNonLatin = true
                        _state.value = _state.value.copy(activeVoiceLocaleLabel = "हिन्दी (hi-IN)")
                    }
                    hasBengali || hasHindi -> {
                        applyEnglishVoice(engine)
                        spokenChunk = transliterateToSpokenPhonetics(chunk)
                        usedNativeNonLatin = false
                        _state.value = _state.value.copy(activeVoiceLocaleLabel = "বাংলা/হিন্দি (Phonetic)")
                    }
                    else -> {
                        applyEnglishVoice(engine)
                        spokenChunk = chunk
                        usedNativeNonLatin = false
                        _state.value = _state.value.copy(activeVoiceLocaleLabel = "English (en-US)")
                    }
                }

                totalEstimatedChars += spokenChunk.length

                activeUtterances[utteranceId] = TrackedUtterance(
                    originalText = chunk,
                    spokenText = spokenChunk,
                    usedNativeNonLatin = usedNativeNonLatin,
                    isWakeGreeting = isWakeGreeting,
                    isLastChunkInBatch = isLast
                )

                val params = Bundle().apply {
                    putInt(TextToSpeech.Engine.KEY_PARAM_STREAM, AudioManager.STREAM_MUSIC)
                    putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, 1.0f)
                }

                val result = engine.speak(spokenChunk, queueMode, params, utteranceId)
                if (result == TextToSpeech.ERROR) {
                    // Immediate fallback to phonetic US English if native locale call returned ERROR
                    activeUtterances.remove(utteranceId)
                    hasNativeBengaliVoice = false
                    applyEnglishVoice(engine)
                    val fallbackText = transliterateToSpokenPhonetics(chunk)
                    val fbId = "${utteranceId}_fb"
                    activeUtterances[fbId] = TrackedUtterance(
                        originalText = chunk,
                        spokenText = fallbackText,
                        usedNativeNonLatin = false,
                        isWakeGreeting = isWakeGreeting,
                        isLastChunkInBatch = isLast
                    )
                    engine.speak(fallbackText, queueMode, params, fbId)
                }
            }

            scheduleSafetyReset(totalEstimatedChars, isWakeGreeting)
        } catch (e: Exception) {
            Log.e(TAG, "Error dispatching TTS chunks", e)
            abandonAudioFocus()
            _state.value = _state.value.copy(isSpeaking = false)
            onSpeechCompleted(isWakeGreeting)
        }
    }

    private fun speakPhoneticFallbackNow(originalText: String, isWakeGreeting: Boolean) {
        val engine = tts ?: return
        try {
            applyEnglishVoice(engine)
            val phonetic = transliterateToSpokenPhonetics(originalText)
            val utteranceId = "ARCHER_PHONETIC_FB_${System.currentTimeMillis()}"
            activeUtterances[utteranceId] = TrackedUtterance(
                originalText = originalText,
                spokenText = phonetic,
                usedNativeNonLatin = false,
                isWakeGreeting = isWakeGreeting,
                isLastChunkInBatch = true
            )
            val params = Bundle().apply {
                putInt(TextToSpeech.Engine.KEY_PARAM_STREAM, AudioManager.STREAM_MUSIC)
                putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, 1.0f)
            }
            _state.value = _state.value.copy(isSpeaking = true)
            engine.speak(phonetic, TextToSpeech.QUEUE_FLUSH, params, utteranceId)
            scheduleSafetyReset(phonetic.length, isWakeGreeting)
        } catch (e: Exception) {
            Log.e(TAG, "speakPhoneticFallbackNow failed", e)
            _state.value = _state.value.copy(isSpeaking = false)
            onSpeechCompleted(isWakeGreeting)
        }
    }

    private fun applyBengaliVoice(engine: TextToSpeech) {
        try {
            val voice = preferredBengaliVoice
            if (voice != null) {
                engine.voice = voice
            } else {
                val bnBd = Locale.forLanguageTag("bn-BD")
                val res = engine.setLanguage(bnBd)
                if (res < TextToSpeech.LANG_AVAILABLE) {
                    engine.language = Locale.forLanguageTag("bn-IN")
                }
            }
        } catch (_: Exception) {
            engine.language = Locale.forLanguageTag("bn-BD")
        }
    }

    private fun applyHindiVoice(engine: TextToSpeech) {
        try {
            val voice = preferredHindiVoice
            if (voice != null) {
                engine.voice = voice
            } else {
                engine.language = Locale.forLanguageTag("hi-IN")
            }
        } catch (_: Exception) {
            engine.language = Locale.forLanguageTag("hi-IN")
        }
    }

    private fun applyEnglishVoice(engine: TextToSpeech) {
        try {
            val voice = preferredEnglishVoice
            if (voice != null) {
                engine.voice = voice
            } else {
                engine.language = Locale.US
            }
        } catch (_: Exception) {
            engine.language = Locale.US
        }
    }

    private fun scheduleSafetyReset(totalChars: Int, isWakeGreeting: Boolean) {
        cancelSafetyReset()
        val estimatedDurationMs = (totalChars * 75L).coerceIn(2200L, 16000L)
        val runnable = Runnable {
            if (_state.value.isSpeaking) {
                abandonAudioFocus()
                _state.value = _state.value.copy(isSpeaking = false)
                onSpeechCompleted(isWakeGreeting)
            }
        }
        safetyResetRunnable = runnable
        mainHandler.postDelayed(runnable, estimatedDurationMs)
    }

    private fun cancelSafetyReset() {
        safetyResetRunnable?.let { mainHandler.removeCallbacks(it) }
        safetyResetRunnable = null
    }

    private fun ensureAudibleMediaStreamVolume() {
        try {
            val am = audioManager ?: return
            val maxVol = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
            val currentVol = am.getStreamVolume(AudioManager.STREAM_MUSIC)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && am.isStreamMute(AudioManager.STREAM_MUSIC)) {
                am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_UNMUTE, 0)
            }
            if (currentVol < (maxVol * 0.45f).toInt()) {
                am.setStreamVolume(
                    AudioManager.STREAM_MUSIC,
                    (maxVol * 0.72f).toInt().coerceAtLeast(1),
                    0
                )
            }
        } catch (_: Exception) {
        }
    }

    private fun requestAudioFocusForSpeech() {
        try {
            val am = audioManager ?: return
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val req = audioFocusRequest ?: AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
                    .setAudioAttributes(speechAudioAttributes)
                    .setAcceptsDelayedFocusGain(false)
                    .setOnAudioFocusChangeListener { }
                    .build()
                    .also { audioFocusRequest = it }
                am.requestAudioFocus(req)
            } else {
                @Suppress("DEPRECATION")
                am.requestAudioFocus(
                    null,
                    AudioManager.STREAM_MUSIC,
                    AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK
                )
            }
        } catch (_: Exception) {
        }
    }

    private fun abandonAudioFocus() {
        try {
            val am = audioManager ?: return
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                audioFocusRequest?.let { am.abandonAudioFocusRequest(it) }
            } else {
                @Suppress("DEPRECATION")
                am.abandonAudioFocus(null)
            }
        } catch (_: Exception) {
        }
    }

    /**
     * Strips markdown, action tags, URLs, and robotic symbols so TTS speaks clean natural sentences.
     */
    fun sanitizeForSpeech(raw: String): String {
        return raw
            .replace(Regex("\\[\\[ACTION:.*?]]", RegexOption.DOT_MATCHES_ALL), "")
            .replace(Regex("\\[\\[ACTION:.*"), "")
            .replace(Regex("https?://\\S+"), "")
            .replace(Regex("[*_`#~>|]"), "")
            .replace("•", ", ")
            .replace("জি বস", "জি স্যার")
            .replace("হ্যালো বস", "হ্যালো স্যার")
            .replace("বসের", "স্যারের")
            .replace(Regex("(?<![অ-হ])বস(?![অ-হ])"), "স্যার")
            .replace(Regex("(?i)\\bboss\\b"), "Sir")
            .replace(Regex("\\s+"), " ")
            .trim()
    }

    /**
     * Splits text into natural sentence chunks so TTS starts speaking immediately and never truncates.
     */
    private fun splitIntoNaturalChunks(text: String): List<String> {
        val rawParts = text.split(Regex("(?<=[।.!?\\n])\\s+"))
            .map { it.trim() }
            .filter { it.isNotBlank() }
        if (rawParts.isEmpty()) return listOf(text)

        val merged = mutableListOf<String>()
        var buffer = StringBuilder()
        for (part in rawParts) {
            if (buffer.isEmpty()) {
                buffer.append(part)
            } else if (buffer.length + part.length + 1 <= 220) {
                buffer.append(" ").append(part)
            } else {
                merged.add(buffer.toString())
                buffer = StringBuilder(part)
            }
        }
        if (buffer.isNotEmpty()) {
            merged.add(buffer.toString())
        }
        return merged
    }

    /**
     * Converts Bengali & Hindi Unicode sentences into natural phonetic Roman/English speech
     * so devices or emulators without `bn-BD` / `hi-IN` voice packs still speak every reply out loud clearly.
     */
    private fun transliterateToSpokenPhonetics(input: String): String {
        var s = input
            .replace("জি স্যার", "Jee Sir")
            .replace("হ্যালো স্যার", "Hello Sir")
            .replace("জি বস", "Jee Sir")
            .replace("হ্যালো বস", "Hello Sir")
            .replace("ওয়ালাইকুম আসসালাম", "Walaikum Assalam")
            .replace("আসসালামু আলাইকুম", "Assalamu Alaikum")
            .replace("স্যার", "Sir")
            .replace("বস", "Sir")
            .replace("আর্চার এআই", "Archer AI")
            .replace("কিউব এআই", "Cube AI")
            .replace("জেমিনি", "Gemini")
            .replace("ইউটিউবে", "YouTube-eh")
            .replace("ইউটিউব", "YouTube")
            .replace("ফ্রি ফায়ার", "Free Fire")
            .replace("ফ্রিফাইয়ার", "Free Fire")
            .replace("পাবজি", "PUBG")
            .replace("হোয়াটসঅ্যাপে", "WhatsApp-eh")
            .replace("হোয়াটসঅ্যাপ", "WhatsApp")
            .replace("টেলিগ্রামে", "Telegram-eh")
            .replace("টেলিগ্রাম", "Telegram")
            .replace("প্লে স্টোর", "Play Store")
            .replace("ক্রোম", "Chrome")
            .replace("ব্রাউজার", "Browser")
            .replace("ডাউনলোড", "download")
            .replace("ইনস্টল", "install")
            .replace("আপডেট", "update")
            .replace("সার্চ", "search")
            .replace("মেমোরিতে", "memory-teh")
            .replace("মেমোরি", "memory")
            .replace("স্ক্রিনে", "screen-eh")
            .replace("স্ক্রিন", "screen")
            .replace("টাইপ", "type")
            .replace("টর্চলাইট", "flashlight")
            .replace("ফ্ল্যাশলাইট", "flashlight")
            .replace("ব্যাটারি", "battery")
            .replace("চার্জ", "charge")
            .replace("ভলিউম", "volume")
            .replace("মিডিয়া", "media")
            .replace("ক্যামেরা", "camera")
            .replace("সেটিংস", "settings")
            .replace("কল", "call")
            .replace("ডায়াল", "dial")
            .replace("গান", "gaan")
            .replace("সময়", "shomoy")
            .replace("তারিখ", "tarikh")
            .replace("আমি প্রস্তুত", "aami prostut")
            .replace("আপনার", "aapnar")
            .replace("আমি", "aami")
            .replace("কেমন আছেন", "kemon aachen")
            .replace("ভালো আছি", "bhalo aachi")
            .replace("করে দিচ্ছি", "kore dicchi")
            .replace("খুলে দিচ্ছি", "khule dicchi")
            .replace("শুরু করছি", "shuru korchi")
            .replace("চালু করছি", "chaalu korchi")
            .replace("ওপেন করছি", "open korchi")
            .replace("পাঠানো হচ্ছে", "pathano hocche")
            .replace("সম্পন্ন হয়েছে", "shomponno hoyeche")
            .replace("।", ". ")
            .replace("॥", ". ")

        val sb = StringBuilder()
        for (ch in s) {
            val mapped = when (ch) {
                // Bengali characters
                'অ' -> "o"
                'আ', 'া' -> "aa"
                'ই', 'ঈ', 'ি', 'ী' -> "ee"
                'উ', 'ঊ', 'ু', 'ূ' -> "u"
                'ঋ', 'ৃ' -> "ri"
                'এ', 'ে' -> "e"
                'ঐ', 'ৈ' -> "oi"
                'ও', 'ো' -> "o"
                'ঔ', 'ৌ' -> "ou"
                'ক' -> "k"
                'খ' -> "kh"
                'গ' -> "g"
                'ঘ' -> "gh"
                'ঙ', 'ং' -> "ng"
                'চ' -> "ch"
                'ছ' -> "chh"
                'জ', 'য' -> "j"
                'ঝ' -> "jh"
                'ঞ' -> "n"
                'ট', 'ত', 'ৎ' -> "t"
                'ঠ', 'থ' -> "th"
                'ড', 'দ' -> "d"
                'ঢ', 'ধ' -> "dh"
                'ণ', 'ন' -> "n"
                'প' -> "p"
                'ফ' -> "ph"
                'ব' -> "b"
                'ভ' -> "bh"
                'ম' -> "m"
                'র', 'ড়', 'ঢ়' -> "r"
                'ল' -> "l"
                'শ', 'ষ', 'স' -> "sh"
                'হ' -> "h"
                'য়' -> "y"
                '্', 'ঁ', 'ঃ' -> ""
                '০' -> "0"
                '১' -> "1"
                '২' -> "2"
                '৩' -> "3"
                '৪' -> "4"
                '৫' -> "5"
                '৬' -> "6"
                '৭' -> "7"
                '৮' -> "8"
                '৯' -> "9"
                // Hindi / Devanagari characters
                'अ' -> "a"
                'आ', 'ा' -> "aa"
                'इ', 'ई', 'ि', 'ी' -> "ee"
                'उ', 'ऊ', 'ु', 'ू' -> "u"
                'ए', 'े' -> "e"
                'ऐ', 'ै' -> "ai"
                'ओ', 'ो' -> "o"
                'औ', 'ौ' -> "au"
                'क' -> "k"
                'ख' -> "kh"
                'ग' -> "g"
                'घ' -> "gh"
                'च' -> "ch"
                'छ' -> "chh"
                'ज' -> "j"
                'झ' -> "jh"
                'ट', 'त' -> "t"
                'ठ', 'थ' -> "th"
                'ड', 'द' -> "d"
                'ढ', 'ध' -> "dh"
                'ण', 'न' -> "n"
                'प' -> "p"
                'फ' -> "ph"
                'ब' -> "b"
                'भ' -> "bh"
                'म' -> "m"
                'य' -> "y"
                'र' -> "r"
                'ल' -> "l"
                'व' -> "v"
                'श', 'ष', 'स' -> "s"
                'ह' -> "h"
                'ं' -> "n"
                '्', 'ँ', 'ः', '़' -> ""
                else -> ch.toString()
            }
            sb.append(mapped)
        }
        return sb.toString()
    }
}
