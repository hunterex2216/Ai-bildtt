package com.example

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.service.AccessibilityAutomationBus
import com.example.service.CubeSentinelBus
import com.example.service.CubeWakeWordService
import com.example.service.NotificationReplyBus
import com.example.ui.screens.AgentCommandScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.util.configureAppCheck
import com.example.viewmodel.OmniAgentViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // STEP 1: Configure App Check with launch intent before any UI or Firebase operations
        configureAppCheck(this, intent)

        // Enable lock-screen visibility and screen wake so "Hey Cube / Archer" works even when locked
        enableLockScreenWakeFlags()

        enableEdgeToEdge()

        // STEP 2: Initialize Compose UI
        setContent {
            MyApplicationTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = Color(0xFF030A07)
                ) {
                    OmniAgentApp()
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        AccessibilityAutomationBus.syncPermissionState(this)
        NotificationReplyBus.syncPermissionState(this)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        configureAppCheck(this, intent)
        if (intent.getBooleanExtra(CubeWakeWordService.EXTRA_WOKE_BY_CUBE, false)) {
            CubeSentinelBus.emitWakeWordDetected()
        }
    }

    @Suppress("DEPRECATION")
    private fun enableLockScreenWakeFlags() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
                setShowWhenLocked(true)
                setTurnScreenOn(true)
            } else {
                window.addFlags(
                    WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                        WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
                )
            }
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        } catch (_: Exception) {
        }
    }
}

@Composable
fun OmniAgentApp(
    viewModel: OmniAgentViewModel = viewModel()
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val plans by viewModel.agentPlans.collectAsStateWithLifecycle()
    val musicState by viewModel.musicState.collectAsStateWithLifecycle()
    val hardwareState by viewModel.hardwareState.collectAsStateWithLifecycle()
    val voiceState by viewModel.voiceState.collectAsStateWithLifecycle()
    val sentinelState by viewModel.sentinelState.collectAsStateWithLifecycle()
    val accessibilityState by viewModel.accessibilityState.collectAsStateWithLifecycle()
    val notificationState by viewModel.notificationState.collectAsStateWithLifecycle()
    val memoryNotes by viewModel.memoryNotes.collectAsStateWithLifecycle()
    val todayTasks by viewModel.todayTasks.collectAsStateWithLifecycle()
    val platformAccounts by viewModel.platformAccounts.collectAsStateWithLifecycle()
    val activeModal by viewModel.activeModal.collectAsStateWithLifecycle()
    val selectedHeadline by viewModel.selectedHeadline.collectAsStateWithLifecycle()
    val isFrontCameraSelected by viewModel.isFrontCameraSelected.collectAsStateWithLifecycle()
    val geminiApiKey by viewModel.geminiApiKeyState.collectAsStateWithLifecycle()
    val liveUserTranscript by viewModel.liveUserTranscript.collectAsStateWithLifecycle()
    val liveArcherReply by viewModel.liveArcherReply.collectAsStateWithLifecycle()
    val codingWorkspaceState by viewModel.codingWorkspaceState.collectAsStateWithLifecycle()
    val lockedReplyLanguage by viewModel.lockedReplyLanguage.collectAsStateWithLifecycle()
    val persistentUserRule by viewModel.persistentUserRule.collectAsStateWithLifecycle()

    Scaffold(
        contentWindowInsets = WindowInsets.safeDrawing,
        containerColor = Color(0xFF030A07)
    ) { innerPadding ->
        AgentCommandScreen(
            uiState = uiState,
            plans = plans,
            liveUserTranscript = liveUserTranscript,
            liveArcherReply = liveArcherReply,
            musicState = musicState,
            hardwareState = hardwareState,
            voiceState = voiceState,
            sentinelState = sentinelState,
            accessibilityState = accessibilityState,
            notificationState = notificationState,
            memoryNotes = memoryNotes,
            todayTasks = todayTasks,
            platformAccounts = platformAccounts,
            headlines = viewModel.headlines,
            activeModal = activeModal,
            selectedHeadline = selectedHeadline,
            isFrontCameraSelected = isFrontCameraSelected,
            geminiApiKey = geminiApiKey,
            onSaveGeminiApiKey = { viewModel.updateGeminiApiKey(it) },
            onSendCommand = { viewModel.processUserCommand(it) },
            onSimulateHeyCube = { viewModel.simulateHeyCubeWakeCall() },
            onToggleAlwaysOnSentinel = { viewModel.toggleAlwaysOnCubeSentinel(it) },
            onExecuteStep = { planId, step -> viewModel.executeSingleStep(planId, step) },
            onSelectMood = { viewModel.playMoodImmediately(it) },
            onOpenExternalMusic = { query, artist -> viewModel.openExternalMusicApp(query, artist) },
            onStopSpeaking = { viewModel.stopAllAgentActivity() },
            onTogglePlayMusic = { viewModel.musicEngine.togglePlayPause() },
            onToggleTts = { viewModel.voiceBridge.toggleTts() },
            onSpeakText = { viewModel.speakTextAloud(it) },
            onReplayLastSpeech = { viewModel.replayLastAgentResponse() },
            onTestTtsVoice = { viewModel.testTtsVoice() },
            onChangeSpeechRate = { viewModel.setTtsSpeechRate(it) },
            onChangeSpeechPitch = { viewModel.setTtsPitch(it) },
            onSelectVoiceProfile = { viewModel.setTtsVoiceProfile(it) },
            onToggleHandsFreeVoice = { viewModel.toggleHandsFreeVoiceMode() },
            onSetHandsFreeVoice = { viewModel.setHandsFreeVoiceMode(it) },
            onCycleSttLanguage = { viewModel.cycleSttLanguage() },
            onSelectSttLanguage = { viewModel.setSttLanguage(it) },
            onExternalSpeechRecognized = { viewModel.onExternalSpeechRecognized(it) },
            codingWorkspaceState = codingWorkspaceState,
            lockedReplyLanguage = lockedReplyLanguage,
            persistentUserRule = persistentUserRule,
            onSetLockedLanguage = { viewModel.setLockedReplyLanguage(it) },
            onSavePersistentRule = { viewModel.setCustomPersistentRule(it) },
            onToggleQuickSettingTile = { target, enable ->
                viewModel.toggleQuickSettingFromUi(target, enable)
            },
            onSelectAiModel = { viewModel.selectAiModel(it) },
            onToggleAutoModelRouting = { viewModel.toggleAutoModelRouting() },
            onSaveManualCodeToArcher = { title, fileName, lang, code ->
                viewModel.saveWorkspaceCodeDirectly(title, fileName, lang, code)
            },
            onShareArcherArtifact = { artifact ->
                viewModel.codingAndContactsManager.shareCodeOrProject(artifact)
            },
            onStartVoiceListening = { viewModel.voiceBridge.startListening(true) },
            onStopVoiceListening = { viewModel.voiceBridge.stopListening() },
            onOpenModal = { viewModel.openModal(it) },
            onSelectHeadline = { viewModel.openHeadlineDetail(it) },
            onToggleCameraFacing = { viewModel.toggleCameraLens() },
            onLaunchSystemCamera = {
                viewModel.deviceExecutor.openCameraApp(false)
                viewModel.speakTextAloud("জি স্যার, ক্যামেরা চালু করা হয়েছে।")
            },
            onAddMemoryNote = { title, content ->
                viewModel.addManualMemoryNote(title, content)
            },
            onDeleteMemoryNote = { viewModel.deleteMemoryNote(it) },
            onSavePlatformAccount = { platform, name, handle, notes ->
                viewModel.addPlatformAccount(platform, name, handle, notes)
            },
            onDeletePlatformAccount = { viewModel.deletePlatformAccount(it) },
            onToggleTodayTask = { viewModel.executeTodayTask(it) },
            onOpenAccessibilitySettings = {
                viewModel.deviceExecutor.openSettingsScreen("ACCESSIBILITY")
                viewModel.speakTextAloud("জি স্যার, অ্যাক্সেসিবিলিটি সেটিংস খোলা হয়েছে।")
            },
            onOpenNotificationListenerSettings = {
                viewModel.deviceExecutor.openSettingsScreen("NOTIFICATION_LISTENER")
                viewModel.speakTextAloud("জি স্যার, নোটিফিকেশন সেটিংস খোলা হয়েছে।")
            },
            onToggleFlashlight = { enable ->
                viewModel.deviceExecutor.setFlashlight(enable)
                viewModel.speakTextAloud(
                    if (enable) "জি স্যার, ফ্ল্যাশলাইট চালু করা হয়েছে।" else "জি স্যার, ফ্ল্যাশলাইট বন্ধ করা হয়েছে।"
                )
            },
            onVolumeChange = { stream, pct ->
                val res = viewModel.deviceExecutor.setStreamVolumePercent(stream, pct, "")
                viewModel.speakTextAloud(res)
            },
            onOpenSystemSetting = { target ->
                viewModel.deviceExecutor.openSettingsScreen(target)
                viewModel.speakTextAloud("জি স্যার, $target সেটিংস খোলা হয়েছে।")
            },
            onTestScreenMacro = { cmd, query ->
                val res = viewModel.deviceExecutor.executeUniversalScreenControl(
                    commandType = cmd,
                    targetText = query,
                    inputText = query,
                    targetApp = "",
                    launchExternal = true
                )
                viewModel.speakTextAloud(res)
            },
            onInstallFromPlayStore = { appQuery ->
                val res = viewModel.deviceExecutor.installApkOrAppPackage(appQuery, true)
                viewModel.speakTextAloud(res)
            },
            onChromeAction = { urlOrQuery ->
                viewModel.deviceExecutor.openChromeOrWeb(urlOrQuery, "")
                viewModel.speakTextAloud("জি স্যার, ক্রোম ব্রাউজারে $urlOrQuery খোলা হচ্ছে।")
            },
            onTelegramDownload = { channel, fileQuery ->
                val res = viewModel.deviceExecutor.executeTelegramAutomation(
                    channelOrUser = channel,
                    messageOrSearch = fileQuery,
                    isDownloadRequest = true,
                    launchExternal = true
                )
                viewModel.speakTextAloud(res)
            },
            onQuickReplyNotification = { sender, reply ->
                viewModel.sendQuickNotificationReply(sender, reply)
            },
            onAnalyzeScreenWithAi = {
                viewModel.analyzeCurrentScreenAndSpeak()
            },
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        )
    }
}
