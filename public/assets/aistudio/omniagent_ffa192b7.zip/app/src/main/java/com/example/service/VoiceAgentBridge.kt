package com.example.service

import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import com.example.model.WakeWordPhase
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class VoiceBridgeState(
    val isListening: Boolean = false,
    val isHandsFreeContinuous: Boolean = false,
    val isSttServiceAvailable: Boolean = true,
    val partialTranscript: String = "",
    val lastRecognizedCommand: String = "",
    val languageCode: String = "bn-BD",
    val languageLabel: String = "বাংলা (bn-BD)",
    val sttConfidence: Float = 0f,
    val ttsEnabled: Boolean = true,
    val isSpeaking: Boolean = false,
    val rmsLevel: Float = 0f,
    val speechRate: Float = 0.95f,
    val pitch: Float = 0.80f,
    val voiceProfile: String = "DEEP_JARVIS",
    val activeVoiceLocaleLabel: String = "Deep & Clean • বাংলা / English",
    val lastSpokenText: String = "জি স্যার, আমি প্রস্তুত। আপনার যেকোনো প্রশ্ন বা আদেশ বলুন।",
    val statusHint: String = "\"Hey Cube\" বলে ডাকুন অথবা মাইকে ট্যাপ করুন"
)

class VoiceAgentBridge(
    private val context: Context,
    private val onWakeWordGreetingTriggered: (String, String) -> Unit,
    private val onPartialTranscriptChanged: (String) -> Unit = {},
    private val onFinalTranscript: (String, Boolean) -> Unit
) {
    private val mainHandler = Handler(Looper.getMainLooper())
    private var awaitingBossCommandAfterWake = false

    private val _state = MutableStateFlow(VoiceBridgeState())
    val state: StateFlow<VoiceBridgeState> = _state.asStateFlow()

    val ttsModule: AgentTtsModule = AgentTtsModule(
        context = context.applicationContext,
        onSpeechStarted = {
            // Pause SpeechRecognizer while TTS is speaking so the mic never echoes speaker audio
            sttModule.pauseForTtsOutput()
            val ttsState = getTtsStateSnapshot()
            _state.value = _state.value.copy(
                isListening = false,
                isSpeaking = true,
                rmsLevel = 0f,
                ttsEnabled = ttsState.isEnabled,
                speechRate = ttsState.speechRate,
                pitch = ttsState.pitch,
                voiceProfile = ttsState.voiceProfile,
                activeVoiceLocaleLabel = ttsState.activeVoiceLocaleLabel,
                lastSpokenText = ttsState.lastSpokenText
            )
        },
        onSpeechCompleted = { wasWakeGreeting ->
            val ttsState = getTtsStateSnapshot()
            _state.value = _state.value.copy(
                isSpeaking = false,
                rmsLevel = 0f,
                ttsEnabled = ttsState.isEnabled,
                speechRate = ttsState.speechRate,
                pitch = ttsState.pitch,
                voiceProfile = ttsState.voiceProfile,
                activeVoiceLocaleLabel = ttsState.activeVoiceLocaleLabel,
                lastSpokenText = ttsState.lastSpokenText
            )
            val sttState = getSttStateSnapshot()
            when {
                wasWakeGreeting -> {
                    mainHandler.postDelayed({
                        awaitingBossCommandAfterWake = true
                        CubeSentinelBus.updatePhase(WakeWordPhase.AWAITING_BOSS_COMMAND)
                        sttModule.startListening(isCommandFollowUp = true)
                    }, 250L)
                }
                sttState.isHandsFreeContinuous -> {
                    mainHandler.postDelayed({
                        awaitingBossCommandAfterWake = true
                        sttModule.startListening(isCommandFollowUp = true)
                    }, 350L)
                }
                CubeSentinelBus.state.value.isSentinelActive -> {
                    mainHandler.postDelayed({
                        CubeSentinelBus.updatePhase(WakeWordPhase.LISTENING_FOR_WAKE_WORD)
                        sttModule.startListening(isCommandFollowUp = false)
                    }, 400L)
                }
            }
        }
    )

    val sttModule: AgentSttModule = AgentSttModule(
        context = context.applicationContext,
        isTtsCurrentlySpeaking = { _state.value.isSpeaking },
        onPartialSpeechUpdate = { partial ->
            _state.value = _state.value.copy(
                partialTranscript = partial,
                statusHint = "শুনছি: \"$partial\""
            )
            onPartialTranscriptChanged(partial)
        },
        onFinalSpeechRecognized = { recognizedText, confidence, _ ->
            handleRecognizedSpeech(recognizedText, confidence)
        },
        onStateChanged = { sttSnapshot ->
            _state.value = _state.value.copy(
                isListening = sttSnapshot.isListening,
                isHandsFreeContinuous = sttSnapshot.isHandsFreeContinuous,
                isSttServiceAvailable = sttSnapshot.isRecognitionServiceAvailable,
                partialTranscript = sttSnapshot.partialTranscript,
                lastRecognizedCommand = sttSnapshot.lastFinalTranscript.ifBlank {
                    _state.value.lastRecognizedCommand
                },
                languageCode = sttSnapshot.languageCode,
                languageLabel = sttSnapshot.languageLabel,
                sttConfidence = sttSnapshot.confidenceScore,
                rmsLevel = sttSnapshot.rmsLevel,
                statusHint = sttSnapshot.statusMessage
            )
        }
    )

    init {
        val initialStt = sttModule.state.value
        _state.value = _state.value.copy(
            isHandsFreeContinuous = initialStt.isHandsFreeContinuous,
            isSttServiceAvailable = initialStt.isRecognitionServiceAvailable,
            languageCode = initialStt.languageCode,
            languageLabel = initialStt.languageLabel
        )
    }

    private fun getTtsStateSnapshot(): TtsEngineState = ttsModule.state.value
    private fun getSttStateSnapshot(): SttEngineState = sttModule.state.value

    private fun handleRecognizedSpeech(best: String, confidence: Float) {
        val cleaned = best.trim()
        if (cleaned.isBlank()) {
            sttModule.scheduleContinuousRestartIfNeeded(delayMs = 500L)
            return
        }

        _state.value = _state.value.copy(
            isListening = false,
            rmsLevel = 0f,
            partialTranscript = cleaned,
            lastRecognizedCommand = cleaned,
            sttConfidence = confidence
        )

        val (isWakeMatch, inlineCmd) = CubeSentinelBus.matchWakeWord(cleaned)
        if (isWakeMatch && inlineCmd.isBlank()) {
            awaitingBossCommandAfterWake = false
            triggerHeyCubeWakeSequence("", cleaned)
        } else if (isWakeMatch && inlineCmd.isNotBlank()) {
            awaitingBossCommandAfterWake = false
            triggerHeyCubeWakeSequence(inlineCmd, cleaned)
        } else {
            val wasWakeFollowUp = awaitingBossCommandAfterWake || _state.value.isHandsFreeContinuous
            awaitingBossCommandAfterWake = false
            CubeSentinelBus.updatePhase(WakeWordPhase.PROCESSING_COMMAND)
            _state.value = _state.value.copy(statusHint = "কমান্ড: \"$cleaned\"")
            onFinalTranscript(cleaned, wasWakeFollowUp)
        }
    }

    fun triggerHeyCubeWakeSequence(inlineCommand: String = "", rawSpokenWake: String = "Hey Cube") {
        playWakeChimeAndHaptic()
        if (inlineCommand.isNotBlank()) {
            CubeSentinelBus.updatePhase(WakeWordPhase.PROCESSING_COMMAND)
            _state.value = _state.value.copy(
                partialTranscript = inlineCommand,
                lastRecognizedCommand = inlineCommand,
                statusHint = "জি স্যার! আদেশ পালন করা হচ্ছে: \"$inlineCommand\""
            )
            onFinalTranscript(inlineCommand, true)
        } else {
            val greeting = CubeSentinelBus.state.value.bossGreeting
            CubeSentinelBus.updatePhase(WakeWordPhase.GREETING_BOSS)
            _state.value = _state.value.copy(
                partialTranscript = rawSpokenWake,
                statusHint = greeting,
                lastSpokenText = greeting
            )
            onWakeWordGreetingTriggered(rawSpokenWake, greeting)
            if (_state.value.ttsEnabled) {
                ttsModule.speak(greeting, isWakeGreeting = true)
            } else {
                mainHandler.postDelayed({
                    awaitingBossCommandAfterWake = true
                    CubeSentinelBus.updatePhase(WakeWordPhase.AWAITING_BOSS_COMMAND)
                    sttModule.startListening(isCommandFollowUp = true)
                }, 300L)
            }
        }
    }

    private fun playWakeChimeAndHaptic() {
        try {
            val toneGen = ToneGenerator(AudioManager.STREAM_MUSIC, 80)
            toneGen.startTone(ToneGenerator.TONE_PROP_BEEP2, 140)
            mainHandler.postDelayed({ toneGen.release() }, 200L)
        } catch (_: Exception) {
        }

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vm = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vm?.defaultVibrator?.vibrate(
                    VibrationEffect.createOneShot(80L, VibrationEffect.DEFAULT_AMPLITUDE)
                )
            } else {
                @Suppress("DEPRECATION")
                val vib = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vib?.vibrate(VibrationEffect.createOneShot(80L, VibrationEffect.DEFAULT_AMPLITUDE))
                } else {
                    @Suppress("DEPRECATION")
                    vib?.vibrate(80L)
                }
            }
        } catch (_: Exception) {
        }
    }

    fun toggleLanguage(): String {
        return sttModule.cycleLanguage()
    }

    fun setSttLanguage(languageCode: String) {
        sttModule.setLanguage(languageCode)
    }

    fun setHandsFreeContinuousMode(enabled: Boolean) {
        sttModule.setHandsFreeContinuousMode(enabled)
    }

    fun toggleHandsFreeContinuousMode(): Boolean {
        return sttModule.toggleHandsFreeContinuousMode()
    }

    fun onExternalSpeechResult(spokenText: String) {
        sttModule.onExternalActivityResult(spokenText)
    }

    fun buildSystemRecognizerFallbackIntent(): Intent {
        return sttModule.buildSystemRecognizerFallbackIntent()
    }

    fun toggleTts() {
        val nextEnabled = ttsModule.toggleEnabled()
        _state.value = _state.value.copy(
            ttsEnabled = nextEnabled,
            isSpeaking = if (!nextEnabled) false else _state.value.isSpeaking
        )
    }

    fun setSpeechRate(rate: Float) {
        ttsModule.setSpeechRate(rate)
        _state.value = _state.value.copy(speechRate = ttsModule.state.value.speechRate)
    }

    fun setPitch(pitch: Float) {
        ttsModule.setPitch(pitch)
        _state.value = _state.value.copy(pitch = ttsModule.state.value.pitch)
    }

    fun applyVoiceProfile(profile: String) {
        ttsModule.applyVoiceProfile(profile)
        val snap = ttsModule.state.value
        _state.value = _state.value.copy(
            voiceProfile = snap.voiceProfile,
            pitch = snap.pitch,
            speechRate = snap.speechRate
        )
    }

    fun speak(text: String, forceSpeakWhenMuted: Boolean = false) {
        if (text.isBlank()) return
        val sanitized = ttsModule.sanitizeForSpeech(text)
        _state.value = _state.value.copy(
            lastSpokenText = sanitized.ifBlank { text },
            ttsEnabled = if (forceSpeakWhenMuted) true else _state.value.ttsEnabled
        )
        ttsModule.speak(
            rawText = text,
            isWakeGreeting = false,
            forceSpeakWhenMuted = forceSpeakWhenMuted
        )
    }

    fun replayLastSpoken() {
        ttsModule.replayLastResponse()
        _state.value = _state.value.copy(ttsEnabled = true, isSpeaking = true)
    }

    fun testTtsVoice() {
        ttsModule.testVoiceOutput()
        _state.value = _state.value.copy(ttsEnabled = true, isSpeaking = true)
    }

    fun stopSpeaking() {
        ttsModule.stopSpeaking()
        _state.value = _state.value.copy(isSpeaking = false)
    }

    fun startListening(isManualCommandTap: Boolean = true) {
        stopSpeaking()
        awaitingBossCommandAfterWake = isManualCommandTap
        sttModule.startListening(isCommandFollowUp = isManualCommandTap)
    }

    fun stopListening(keepSentinelPhase: Boolean = false) {
        mainHandler.removeCallbacksAndMessages(null)
        sttModule.stopListening()
        if (!keepSentinelPhase && !CubeSentinelBus.state.value.isSentinelActive) {
            CubeSentinelBus.updatePhase(WakeWordPhase.INACTIVE)
        }
    }

    fun release() {
        stopListening()
        sttModule.release()
        ttsModule.release()
    }
}
