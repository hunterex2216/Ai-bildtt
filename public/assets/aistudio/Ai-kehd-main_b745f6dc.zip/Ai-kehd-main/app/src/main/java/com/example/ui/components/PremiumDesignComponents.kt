package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.PI
import kotlin.math.roundToInt
import kotlin.math.sin

// Unified Executive Luxury Palette: Champagne Gold & Titanium Cyan on Deep Carbon Slate
val LuxuryGold = Color(0xFFF5C451)
val ChampagneHighlight = Color(0xFFFFE49E)
val TitaniumCyan = Color(0xFF38E8FF)
val ExecutiveSlateDark = Color(0xFF070C14)
val ExecutiveSlateMid = Color(0xFF0D1523)
val ExecutiveSlateLight = Color(0xFF142034)
val ExecutiveBorder = Color(0xFF233552)

// Legacy aliases mapped to the unified executive palette so all modals stay cohesive and never rainbow-clashed
val RoyalViolet = TitaniumCyan
val RoseNeon = LuxuryGold
val SapphireBlue = TitaniumCyan
val CoralSunset = LuxuryGold
val ElectricMagenta = TitaniumCyan
val MintTurquoise = TitaniumCyan
val DeepObsidian = ExecutiveSlateDark
val GlassEmeraldDark = ExecutiveSlateMid
val GlassEmeraldMid = ExecutiveSlateLight
val GlassCyanDark = ExecutiveSlateMid

/**
 * Ultra-refined Executive Modal Shell with unified Deep Carbon Slate + Champagne Gold & Titanium Cyan
 * brushed metallic header, subtle harmonic telemetry wave, and sculpted 3D category buttons.
 */
@Composable
fun PremiumModalShell(
    badgeText: String,
    title: String,
    subtitle: String,
    accentColor: Color,
    secondaryAccent: Color = TitaniumCyan,
    onClose: () -> Unit,
    tabs: List<Pair<String, String>> = emptyList(),
    selectedTab: String = "",
    onSelectTab: (String) -> Unit = {},
    content: @Composable ColumnScope.() -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "modal_glow")
    val wavePhase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = (2f * PI).toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 4600, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "modal_wave_phase"
    )

    val outerShape = RoundedCornerShape(28.dp)
    val headerShape = RoundedCornerShape(topStart = 26.dp, topEnd = 26.dp, bottomStart = 18.dp, bottomEnd = 18.dp)

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xEE04070D))
            .padding(horizontal = 10.dp, vertical = 12.dp),
        contentAlignment = Alignment.Center
    ) {
        Surface(
            shape = outerShape,
            color = ExecutiveSlateDark,
            border = BorderStroke(
                width = 1.6.dp,
                brush = Brush.linearGradient(
                    colors = listOf(
                        LuxuryGold.copy(alpha = 0.85f),
                        TitaniumCyan.copy(alpha = 0.55f),
                        ExecutiveBorder,
                        LuxuryGold.copy(alpha = 0.70f)
                    )
                )
            ),
            modifier = Modifier
                .fillMaxSize()
                .testTag("jarvis_active_modal")
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                // 1. Unified Executive Brushed Carbon-Gold Header Banner
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(headerShape)
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(
                                    Color(0xFF152238),
                                    Color(0xFF0C1422),
                                    ExecutiveSlateDark
                                )
                            )
                        )
                        .border(
                            width = 1.dp,
                            brush = Brush.horizontalGradient(
                                colors = listOf(
                                    LuxuryGold.copy(alpha = 0.70f),
                                    TitaniumCyan.copy(alpha = 0.45f),
                                    LuxuryGold.copy(alpha = 0.70f)
                                )
                            ),
                            shape = headerShape
                        )
                ) {
                    Canvas(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(if (tabs.isNotEmpty()) 130.dp else 94.dp)
                    ) {
                        val gridStep = 26.dp.toPx()
                        var x = 0f
                        while (x < size.width) {
                            drawLine(
                                color = TitaniumCyan.copy(alpha = 0.05f),
                                start = Offset(x, 0f),
                                end = Offset(x, size.height),
                                strokeWidth = 0.8.dp.toPx()
                            )
                            x += gridStep
                        }

                        // Warm Champagne Gold ambient top glow
                        drawCircle(
                            brush = Brush.radialGradient(
                                colors = listOf(
                                    LuxuryGold.copy(alpha = 0.22f),
                                    TitaniumCyan.copy(alpha = 0.08f),
                                    Color.Transparent
                                ),
                                center = Offset(size.width * 0.28f, 0f),
                                radius = size.width * 0.65f
                            ),
                            radius = size.width * 0.65f,
                            center = Offset(size.width * 0.28f, 0f)
                        )

                        // Subtle harmonic gold-cyan telemetry line
                        val path = Path()
                        val steps = 48
                        val stepX = size.width / steps
                        val baseY = size.height * 0.78f
                        for (i in 0..steps) {
                            val px = i * stepX
                            val py = baseY + sin(wavePhase + i * 0.28f) * 5.dp.toPx()
                            if (i == 0) path.moveTo(px, py) else path.lineTo(px, py)
                        }
                        drawPath(
                            path = path,
                            brush = Brush.horizontalGradient(
                                colors = listOf(
                                    Color.Transparent,
                                    LuxuryGold.copy(alpha = 0.45f),
                                    TitaniumCyan.copy(alpha = 0.50f),
                                    Color.Transparent
                                )
                            ),
                            style = Stroke(width = 1.5.dp.toPx(), cap = StrokeCap.Round)
                        )
                    }

                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                // Executive Champagne Gold Badge Pill
                                Surface(
                                    color = LuxuryGold.copy(alpha = 0.14f),
                                    shape = RoundedCornerShape(50),
                                    border = BorderStroke(1.dp, LuxuryGold.copy(alpha = 0.75f))
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 3.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(6.dp)
                                                .clip(CircleShape)
                                                .background(LuxuryGold)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = badgeText,
                                            color = ChampagneHighlight,
                                            fontSize = 9.5.sp,
                                            fontWeight = FontWeight.ExtraBold,
                                            letterSpacing = 1.1.sp
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(6.dp))

                                Text(
                                    text = title,
                                    color = Color.White,
                                    fontSize = 15.5.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )

                                Text(
                                    text = subtitle,
                                    color = Color(0xFFB8CAE0),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Medium,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }

                            Spacer(modifier = Modifier.width(10.dp))

                            // Sculpted 3D Metallic Close Button
                            Box(
                                contentAlignment = Alignment.Center,
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(RoundedCornerShape(13.dp))
                                    .background(
                                        Brush.verticalGradient(
                                            colors = listOf(
                                                Color(0xFF1C2B42),
                                                Color(0xFF0E1624)
                                            )
                                        )
                                    )
                                    .border(
                                        1.3.dp,
                                        Brush.linearGradient(listOf(LuxuryGold, TitaniumCyan.copy(alpha = 0.7f))),
                                        RoundedCornerShape(13.dp)
                                    )
                                    .clickable { onClose() }
                                    .testTag("modal_close_btn")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "বন্ধ করুন",
                                    tint = ChampagneHighlight,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }

                        // Unified Executive Category Navigation Buttons
                        if (tabs.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(10.dp))
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                tabs.forEach { (tabId, tabLabel) ->
                                    val isSelected = selectedTab == tabId
                                    val tabShape = RoundedCornerShape(12.dp)
                                    Box(
                                        modifier = Modifier
                                            .clip(tabShape)
                                            .background(
                                                if (isSelected) {
                                                    Brush.verticalGradient(
                                                        colors = listOf(
                                                            ChampagneHighlight,
                                                            LuxuryGold
                                                        )
                                                    )
                                                } else {
                                                    Brush.verticalGradient(
                                                        colors = listOf(
                                                            Color(0xFF162338),
                                                            Color(0xFF0C1422)
                                                        )
                                                    )
                                                }
                                            )
                                            .border(
                                                width = if (isSelected) 1.4.dp else 1.dp,
                                                color = if (isSelected) Color.White.copy(alpha = 0.9f) else ExecutiveBorder,
                                                shape = tabShape
                                            )
                                            .clickable { onSelectTab(tabId) }
                                            .padding(horizontal = 14.dp, vertical = 7.dp)
                                    ) {
                                        Text(
                                            text = tabLabel,
                                            color = if (isSelected) Color(0xFF060B12) else Color(0xFFE2ECF8),
                                            fontWeight = FontWeight.ExtraBold,
                                            fontSize = 11.sp
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                // 2. Main Modal Body Content
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    content = content
                )
            }
        }
    }
}

/**
 * Executive Carbon-Slate Section Card with unified Champagne Gold & Titanium Cyan trim.
 */
@Composable
fun PremiumSectionCard(
    title: String,
    subtitle: String = "",
    icon: ImageVector? = null,
    accentColor: Color = LuxuryGold,
    badgeText: String = "",
    modifier: Modifier = Modifier,
    headerTrailing: (@Composable () -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val cardShape = RoundedCornerShape(20.dp)
    Surface(
        shape = cardShape,
        color = Color.Transparent,
        border = BorderStroke(
            width = 1.3.dp,
            brush = Brush.linearGradient(
                colors = listOf(
                    LuxuryGold.copy(alpha = 0.65f),
                    ExecutiveBorder,
                    TitaniumCyan.copy(alpha = 0.45f)
                )
            )
        ),
        modifier = modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            Color(0xFF121D30),
                            Color(0xFF0B121F),
                            Color(0xFF080D17)
                        )
                    )
                )
                .padding(15.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    modifier = Modifier.weight(1f),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (icon != null) {
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier
                                .size(40.dp)
                                .clip(RoundedCornerShape(13.dp))
                                .background(
                                    Brush.verticalGradient(
                                        colors = listOf(
                                            LuxuryGold.copy(alpha = 0.24f),
                                            Color(0xFF0E1829)
                                        )
                                    )
                                )
                                .border(1.1.dp, LuxuryGold.copy(alpha = 0.80f), RoundedCornerShape(13.dp))
                        ) {
                            Icon(
                                imageVector = icon,
                                contentDescription = null,
                                tint = ChampagneHighlight,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(11.dp))
                    }

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = title,
                            color = Color.White,
                            fontSize = 13.5.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                        if (subtitle.isNotBlank()) {
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = subtitle,
                                color = Color(0xFFB4C7DF),
                                fontSize = 11.sp,
                                lineHeight = 14.5.sp
                            )
                        }
                    }
                }

                if (headerTrailing != null) {
                    Spacer(modifier = Modifier.width(8.dp))
                    headerTrailing()
                } else if (badgeText.isNotBlank()) {
                    Spacer(modifier = Modifier.width(8.dp))
                    Surface(
                        color = LuxuryGold.copy(alpha = 0.15f),
                        shape = RoundedCornerShape(50),
                        border = BorderStroke(1.dp, LuxuryGold.copy(alpha = 0.70f))
                    ) {
                        Text(
                            text = badgeText,
                            color = ChampagneHighlight,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.ExtraBold,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))
            content()
        }
    }
}

/**
 * Sculpted 3D Executive Luxury Button:
 * - Solid style: Brushed Champagne Gold gradient with crisp specular top border and dark obsidian text.
 * - Outlined style: Brushed Carbon-Titanium metallic button with glowing Gold/Cyan rim.
 */
@Composable
fun PremiumActionButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
    primaryColor: Color = LuxuryGold,
    secondaryColor: Color = TitaniumCyan,
    isOutlined: Boolean = false,
    testTag: String = ""
) {
    val shape = RoundedCornerShape(14.dp)
    val baseMod = if (testTag.isNotBlank()) modifier.testTag(testTag) else modifier

    if (isOutlined) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = baseMod
                .height(44.dp)
                .clip(shape)
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            Color(0xFF17253B),
                            Color(0xFF0C1524)
                        )
                    )
                )
                .border(
                    width = 1.3.dp,
                    brush = Brush.horizontalGradient(
                        colors = listOf(
                            LuxuryGold.copy(alpha = 0.80f),
                            TitaniumCyan.copy(alpha = 0.75f)
                        )
                    ),
                    shape = shape
                )
                .clickable { onClick() }
                .padding(horizontal = 13.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                if (icon != null) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = ChampagneHighlight,
                        modifier = Modifier.size(17.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                }
                Text(
                    text = text,
                    color = Color.White,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 12.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    } else {
        Box(
            contentAlignment = Alignment.Center,
            modifier = baseMod
                .height(44.dp)
                .clip(shape)
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            ChampagneHighlight,
                            LuxuryGold,
                            Color(0xFFD89E28)
                        )
                    )
                )
                .border(
                    width = 1.2.dp,
                    brush = Brush.verticalGradient(
                        colors = listOf(
                            Color.White.copy(alpha = 0.85f),
                            LuxuryGold.copy(alpha = 0.5f)
                        )
                    ),
                    shape = shape
                )
                .clickable { onClick() }
                .padding(horizontal = 14.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                if (icon != null) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = Color(0xFF070C14),
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                }
                Text(
                    text = text,
                    color = Color(0xFF070C14),
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 12.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

/**
 * Sculpted 3D Executive Hardware Control Tile with unified Champagne Gold active state
 * and Deep Carbon-Titanium inactive state.
 */
@Composable
fun PremiumControlCenterTile(
    title: String,
    statusLabel: String,
    icon: ImageVector,
    isActive: Boolean,
    activeColor: Color = LuxuryGold,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    testTag: String = ""
) {
    val bgBrush = if (isActive) {
        Brush.verticalGradient(
            colors = listOf(
                Color(0xFF282419),
                Color(0xFF161A26),
                Color(0xFF0D131F)
            )
        )
    } else {
        Brush.verticalGradient(
            colors = listOf(
                Color(0xFF131E30),
                Color(0xFF0B121E)
            )
        )
    }

    val borderColor by animateColorAsState(
        targetValue = if (isActive) LuxuryGold else ExecutiveBorder,
        label = "tile_border"
    )

    val tileShape = RoundedCornerShape(16.dp)
    val taggedMod = if (testTag.isNotBlank()) modifier.testTag(testTag) else modifier

    Box(
        modifier = taggedMod
            .clip(tileShape)
            .background(bgBrush)
            .border(if (isActive) 1.5.dp else 1.1.dp, borderColor, tileShape)
            .clickable { onClick() }
            .padding(horizontal = 12.dp, vertical = 10.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .size(35.dp)
                        .clip(RoundedCornerShape(11.dp))
                        .background(
                            if (isActive) {
                                Brush.verticalGradient(listOf(ChampagneHighlight, LuxuryGold))
                            } else {
                                Brush.verticalGradient(listOf(Color(0xFF1B2B44), Color(0xFF101A2B)))
                            }
                        )
                        .border(
                            1.dp,
                            if (isActive) Color.White.copy(alpha = 0.7f) else TitaniumCyan.copy(alpha = 0.40f),
                            RoundedCornerShape(11.dp)
                        )
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = title,
                        tint = if (isActive) Color(0xFF070C14) else TitaniumCyan,
                        modifier = Modifier.size(18.dp)
                    )
                }
                Spacer(modifier = Modifier.width(9.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = title,
                        color = Color.White,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 11.5.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = statusLabel,
                        color = if (isActive) ChampagneHighlight else Color(0xFF8EA4C2),
                        fontWeight = FontWeight.Bold,
                        fontSize = 9.5.sp,
                        maxLines = 1
                    )
                }
            }

            // Glowing Status LED
            Box(
                modifier = Modifier
                    .size(9.dp)
                    .clip(CircleShape)
                    .background(if (isActive) LuxuryGold else Color(0xFF283A54))
            )
        }
    }
}

/**
 * Unified Executive Studio Equalizer / Volume Channel Row with Champagne Gold & Titanium Cyan meter.
 */
@Composable
fun PremiumStudioVolumeChannel(
    label: String,
    percent: Int,
    accentColor: Color = LuxuryGold,
    onPercentChange: (Int) -> Unit,
    sliderTestTag: String
) {
    Surface(
        color = Color.Transparent,
        shape = RoundedCornerShape(15.dp),
        border = BorderStroke(1.1.dp, ExecutiveBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            Color(0xFF131F32),
                            Color(0xFF0B121F)
                        )
                    )
                )
                .padding(horizontal = 12.dp, vertical = 9.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = label,
                    color = Color.White,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 12.sp,
                    modifier = Modifier.weight(1f)
                )

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    // -15% Sculpted Button
                    Surface(
                        color = Color(0xFF17263D),
                        shape = RoundedCornerShape(8.dp),
                        border = BorderStroke(1.dp, TitaniumCyan.copy(alpha = 0.55f)),
                        modifier = Modifier.clickable {
                            onPercentChange((percent - 15).coerceAtLeast(0))
                        }
                    ) {
                        Text(
                            text = "−15%",
                            color = TitaniumCyan,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.ExtraBold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }

                    // Percentage Badge
                    Surface(
                        color = LuxuryGold.copy(alpha = 0.18f),
                        shape = RoundedCornerShape(8.dp),
                        border = BorderStroke(1.dp, LuxuryGold)
                    ) {
                        Text(
                            text = "$percent%",
                            color = ChampagneHighlight,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 11.sp,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }

                    // +15% Sculpted Button
                    Surface(
                        color = Color(0xFF242118),
                        shape = RoundedCornerShape(8.dp),
                        border = BorderStroke(1.dp, LuxuryGold.copy(alpha = 0.80f)),
                        modifier = Modifier.clickable {
                            onPercentChange((percent + 15).coerceAtMost(100))
                        }
                    ) {
                        Text(
                            text = "+15%",
                            color = ChampagneHighlight,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.ExtraBold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Unified Titanium-to-Gold Studio LED Bar
            Canvas(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
            ) {
                val segments = 24
                val gap = 3.dp.toPx()
                val segWidth = (size.width - gap * (segments - 1)) / segments
                val activeSegments = ((percent / 100f) * segments).roundToInt()
                for (i in 0 until segments) {
                    val segColor = when {
                        i >= activeSegments -> Color(0xFF1A283E)
                        i > segments * 0.65f -> LuxuryGold
                        else -> TitaniumCyan
                    }
                    drawRoundRect(
                        color = segColor,
                        topLeft = Offset(i * (segWidth + gap), 0f),
                        size = Size(segWidth, size.height),
                        cornerRadius = CornerRadius(2.dp.toPx(), 2.dp.toPx())
                    )
                }
            }

            Slider(
                value = percent.toFloat(),
                onValueChange = { onPercentChange(it.roundToInt()) },
                valueRange = 0f..100f,
                colors = SliderDefaults.colors(
                    thumbColor = ChampagneHighlight,
                    activeTrackColor = LuxuryGold,
                    inactiveTrackColor = Color(0xFF1B2A40)
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(26.dp)
                    .testTag(sliderTestTag)
            )
        }
    }
}

/**
 * Unified Executive Voice Studio Card for the 16 Female & Male Gemini Voices.
 */
@Composable
fun PremiumVoiceStudioTile(
    titleBn: String,
    subtitleBn: String,
    voiceCode: String,
    isFemale: Boolean,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    testTag: String = ""
) {
    val accent = if (isSelected) LuxuryGold else TitaniumCyan
    val cardShape = RoundedCornerShape(16.dp)
    val taggedMod = if (testTag.isNotBlank()) modifier.testTag(testTag) else modifier

    Surface(
        shape = cardShape,
        color = Color.Transparent,
        border = BorderStroke(
            width = if (isSelected) 1.7.dp else 1.dp,
            color = if (isSelected) LuxuryGold else ExecutiveBorder
        ),
        modifier = taggedMod
            .clip(cardShape)
            .clickable { onClick() }
    ) {
        Column(
            modifier = Modifier
                .background(
                    if (isSelected) {
                        Brush.verticalGradient(
                            colors = listOf(
                                Color(0xFF282318),
                                Color(0xFF121A2B)
                            )
                        )
                    } else {
                        Brush.verticalGradient(
                            colors = listOf(
                                Color(0xFF121D30),
                                Color(0xFF0A111D)
                            )
                        )
                    }
                )
                .padding(11.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    color = accent.copy(alpha = 0.15f),
                    shape = RoundedCornerShape(50),
                    border = BorderStroke(0.9.dp, accent.copy(alpha = 0.7f))
                ) {
                    Text(
                        text = if (isFemale) "👩 FEMALE • $voiceCode" else "🎙️ MALE • $voiceCode",
                        color = if (isSelected) ChampagneHighlight else TitaniumCyan,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.ExtraBold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                    )
                }

                if (isSelected) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = "Selected",
                        tint = LuxuryGold,
                        modifier = Modifier.size(16.dp)
                    )
                } else {
                    Icon(
                        imageVector = Icons.Default.GraphicEq,
                        contentDescription = null,
                        tint = TitaniumCyan.copy(alpha = 0.70f),
                        modifier = Modifier.size(15.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = titleBn,
                color = Color.White,
                fontWeight = FontWeight.ExtraBold,
                fontSize = 12.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            Spacer(modifier = Modifier.height(2.dp))

            Text(
                text = subtitleBn,
                color = Color(0xFFB5C7DF),
                fontSize = 10.sp,
                lineHeight = 13.sp,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

/**
 * Unified Executive Permission Status Row with sculpted status badge and action button.
 */
@Composable
fun PremiumPermissionStatusRow(
    stepNumber: String,
    title: String,
    description: String,
    isGranted: Boolean,
    buttonTextGranted: String = "সক্রিয় ✓",
    buttonTextDenied: String = "অন করুন",
    accentColor: Color = LuxuryGold,
    onClick: () -> Unit,
    buttonTestTag: String = ""
) {
    val rowShape = RoundedCornerShape(16.dp)
    val statusColor = if (isGranted) TitaniumCyan else LuxuryGold

    Surface(
        color = Color(0xFF0E1726),
        shape = rowShape,
        border = BorderStroke(1.1.dp, if (isGranted) TitaniumCyan.copy(alpha = 0.55f) else LuxuryGold.copy(alpha = 0.55f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier.weight(1f),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .size(34.dp)
                        .clip(CircleShape)
                        .background(statusColor.copy(alpha = 0.16f))
                        .border(1.2.dp, statusColor, CircleShape)
                ) {
                    Text(
                        text = stepNumber,
                        color = statusColor,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 12.sp
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = title,
                        color = Color.White,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 12.sp
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = description,
                        color = Color(0xFFB8CBE2),
                        fontSize = 10.5.sp,
                        lineHeight = 13.5.sp
                    )
                }
            }

            Spacer(modifier = Modifier.width(10.dp))

            PremiumActionButton(
                text = if (isGranted) buttonTextGranted else buttonTextDenied,
                onClick = onClick,
                isOutlined = isGranted,
                testTag = buttonTestTag,
                modifier = Modifier.width(106.dp)
            )
        }
    }
}
